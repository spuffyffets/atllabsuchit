library(shiny)

# Define UI
ui <- fluidPage(
  titlePanel("Simple Calculator"),
  sidebarLayout(
    sidebarPanel(
      numericInput("num1", "Enter first number:", value = 0),
      numericInput("num2", "Enter second number:", value = 0),
      selectInput("operation", "Choose operation:",
                  choices = c("Addition" = "add",
                              "Subtraction" = "subtract",
                              "Multiplication" = "multiply",
                              "Division" = "divide")),
      actionButton("calculate", "Calculate")
    ),
    mainPanel(
      h3("Result:"),
      textOutput("result")
    )
  )
)

# Define Server
server <- function(input, output) {
  observeEvent(input$calculate, {
    num1 <- input$num1
    num2 <- input$num2
    operation <- input$operation
    
    result <- switch(operation,
                     add = num1 + num2,
                     subtract = num1 - num2,
                     multiply = num1 * num2,
                     divide = ifelse(num2 != 0, num1 / num2, "Division by zero is not allowed"))
    
    output$result <- renderText({
      paste("The result is:", result)
    })
  })
}

# Run the app
shinyApp(ui = ui, server = server)
