library(shiny)

# UI
ui <- fluidPage(
  titlePanel("Text Analysis Tool"),
  sidebarLayout(
    sidebarPanel(
      textAreaInput("text_input", "Enter your text:", rows = 5, placeholder = "Type or paste text here..."),
      actionButton("analyze", "Analyze Text")
    ),
    mainPanel(
      h3("Text Analysis Results:"),
      textOutput("word_count"),
      textOutput("char_count")
    )
  )
)

# Server
server <- function(input, output) {
  observeEvent(input$analyze, {
    text <- input$text_input
    
    output$word_count <- renderText({
      paste("Word Count:", str_count(text, "\\w+"))
    })
    
    output$char_count <- renderText({
      paste("Character Count (including spaces):", nchar(text))
    })
  })
}

# Run the app
shinyApp(ui = ui, server = server)
