library(shiny)

ui <- fluidPage(
  titlePanel("Square Root and Cube Root Calculator"),
  sidebarLayout(
    sidebarPanel(
      numericInput("number", "Enter a number:", value = 1),
      actionButton("calculate", "Calculate")
    ),
    mainPanel(
      h3("Results:"),
      textOutput("sqrt_result"),
      textOutput("cbrt_result")
    )
  )
)

server <- function(input, output) {
  observeEvent(input$calculate, {
    number <- input$number
    
    output$sqrt_result <- renderText({
      paste("Square root of", number, "is:", sqrt(number))
    })
    
    output$cbrt_result <- renderText({
      paste("Cube root of", number, "is:", number^(1/3))
    })
  })
}

shinyApp(ui = ui, server = server)
