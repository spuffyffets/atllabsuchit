library(shiny)

# Define UI
ui <- fluidPage(
  titlePanel("Square and Cube Calculator"),
  sidebarLayout(
    sidebarPanel(
      numericInput("number", "Enter a number:", value = 1),
      actionButton("calculate", "Calculate")
    ),
    mainPanel(
      h3("Results:"),
      textOutput("square_result"),
      textOutput("cube_result")
    )
  )
)

# Define Server
server <- function(input, output) {
  observeEvent(input$calculate, {
    number <- input$number
    
    output$square_result <- renderText({
      paste("Square of", number, "is:", number^2)
    })
    
    output$cube_result <- renderText({
      paste("Cube of", number, "is:", number^3)
    })
  })
}

# Run the app
shinyApp(ui = ui, server = server)
