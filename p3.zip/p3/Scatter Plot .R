library(shiny)

# UI
ui <- fluidPage(
  titlePanel("Dynamic Scatter Plot"),
  sidebarLayout(
    sidebarPanel(
      selectInput("x_var", "Select X-axis Variable:", 
                  choices = names(iris)[1:4], 
                  selected = "Sepal.Length"),
      selectInput("y_var", "Select Y-axis Variable:", 
                  choices = names(iris)[1:4], 
                  selected = "Sepal.Width"),
      checkboxInput("show_legend", "Show Legend", value = TRUE)
    ),
    mainPanel(
      plotOutput("scatter_plot")
    )
  )
)

# Server
server <- function(input, output) {
  output$scatter_plot <- renderPlot({
    plot(
      iris[[input$x_var]], 
      iris[[input$y_var]], 
      col = as.numeric(iris$Species),
      pch = 19,
      xlab = input$x_var,
      ylab = input$y_var,
      main = "Scatter Plot of Iris Dataset"
    )
    if (input$show_legend) {
      legend("topright", legend = levels(iris$Species), col = 1:3, pch = 19)
    }
  })
}

# Run the app
shinyApp(ui = ui, server = server)
