# Load required libraries
library(shiny)
library(rpart)
library(rpart.plot)

# UI definition
ui <- fluidPage(
  titlePanel("Decision Tree Generator"),
  
  sidebarLayout(
    sidebarPanel(
      fileInput("datafile", "Upload CSV File:", accept = c(".csv")),
      textInput("target", "Enter Target Column Name:", value = "PassFail"),  # Default target column is "PassFail"
      uiOutput("feature_input"),
      actionButton("generate", "Generate Decision Tree")
    ),
    
    mainPanel(
      plotOutput("tree_plot"),
      verbatimTextOutput("summary_output")
    )
  )
)

# Server function
server <- function(input, output, session) {
  
  # Reactive value to store the dataset
  dataset <- reactiveVal()
  
  # Observe file input and load dataset
  observeEvent(input$datafile, {
    req(input$datafile)
    dataset(read.csv(input$datafile$datapath))
  })
  
  # Dynamically create checkbox inputs for features
  output$feature_input <- renderUI({
    req(dataset())
    checkboxGroupInput("features", "Select Features:", 
                       choices = setdiff(names(dataset()), input$target))
  })
  
  # Generate decision tree model and plot
  observeEvent(input$generate, {
    req(dataset(), input$target, input$features)
    
    # Create a formula for decision tree based on selected features
    formula <- as.formula(paste(input$target, "~", paste(input$features, collapse = "+")))
    
    # Build the decision tree model
    model <- rpart(formula, data = dataset(), method = "class")
    
    # Plot the decision tree
    output$tree_plot <- renderPlot({
      rpart.plot(model)
    })
    
    # Display model summary
    output$summary_output <- renderPrint({
      summary(model)
    })
  })
}

# Run the app
shinyApp(ui = ui, server = server)
